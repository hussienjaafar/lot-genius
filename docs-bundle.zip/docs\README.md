# Documentation

For complete Lot Genius documentation, see [INDEX.md](INDEX.md).

This README.md serves as a redirect to maintain compatibility with documentation tools that expect a README in the docs/ directory.